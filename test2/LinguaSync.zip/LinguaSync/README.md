# Video Meeting Web App with Python Flask and ZegoCloud API

Install with Terminal
- pip install Flask
- pip install Flask-WTF
- pip install Flask-SQLAlchemy

Get ZegoCloud API Keys from: https://bit.ly/3PNjNTW

Howto: https://youtu.be/n1VmVtMNmHc
